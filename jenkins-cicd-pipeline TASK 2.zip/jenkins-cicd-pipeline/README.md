# Task 2: Simple Jenkins Pipeline for CI/CD (Jenkins + Docker)

A declarative **Jenkinsfile** that automatically builds, tests and deploys a small Node.js web app as a Docker container every time code is committed.

**Tools:** Jenkins, Docker, Git/GitHub, Node.js

## How it works

```
git push ──► GitHub ──(webhook / SCM poll)──► Jenkins
                                                │
        Checkout ─► Build ─► Test ─► Deploy ─► Verify
                     │         │        │          │
              docker build  tests run  docker run  /health
              (image:BUILD#) in Docker  port 3000   smoke test
```

| Stage | What it does |
|-------|--------------|
| **Checkout** | Pulls the latest code from the repo |
| **Build** | Builds the production Docker image, tagged with the Jenkins build number |
| **Test** | Builds the Dockerfile's `test` stage, which runs `npm test`; a failing test fails the build |
| **Deploy** | Removes the old container and starts the new image on port 3000 |
| **Verify** | Calls `/health` inside the container to confirm the app is up |

The build trigger is `githubPush()` (GitHub webhook) with `pollSCM('H/2 * * * *')` as a fallback.

## Project structure

```
.
├── Jenkinsfile          # the pipeline (deliverable)
├── Dockerfile           # multi-stage: base -> test -> production
├── app.js               # tiny Node.js web server (/ and /health)
├── test/app.test.js     # unit tests (Node's built-in test runner)
├── package.json
├── jenkins/Dockerfile   # Jenkins image with Docker CLI included
├── INTERVIEW_QA.md      # answers to the task's interview questions
└── screenshots/         # Jenkins dashboard / console / app screenshots
```

## Run it yourself

### 1. Start Jenkins (with Docker access)

```bash
docker build -t jenkins-docker ./jenkins

docker run -d --name jenkins -u root \
  -p 8080:8080 -p 50000:50000 \
  -v jenkins_home:/var/jenkins_home \
  -v /var/run/docker.sock:/var/run/docker.sock \
  jenkins-docker
```

Open http://localhost:8080, get the admin password with
`docker exec jenkins cat /var/jenkins_home/secrets/initialAdminPassword`,
choose **Install suggested plugins**, and create an admin user.

> The socket mount and `-u root` are for local learning only; don't do this on a shared or production server.

### 2. Create the pipeline job

1. **New Item** → name `jenkins-docker-demo` → **Pipeline** → OK
2. Under **Build Triggers** tick **GitHub hook trigger for GITScm polling** and **Poll SCM** with `H/2 * * * *`
3. Under **Pipeline** choose **Pipeline script from SCM** → **Git**
4. Repository URL: your GitHub repo URL · Branch: `*/main` · Script Path: `Jenkinsfile`
5. Save → **Build Now**

### 3. (Optional) Instant triggering with a webhook

In GitHub: **Settings → Webhooks → Add webhook**
Payload URL `http://<your-public-jenkins-url>/github-webhook/`, content type `application/json`, event: *Just the push event*.
A Jenkins running on `localhost` isn't reachable from GitHub, so either expose it with a tunnel (e.g. ngrok) or rely on the 2-minute SCM poll.

### 4. Test the pipeline

1. Edit `app.js` (e.g. change the heading), commit and push
2. Watch Jenkins start a new build automatically
3. Open http://localhost:3000. The page shows the new build number

To see a failure, break a test, push, and watch the **Test** stage turn red and block the deploy.

## Screenshots

| | |
|---|---|
| Jenkins dashboard | ![dashboard](screenshots/01-jenkins-dashboard.png) |
| Pipeline stage view | ![stages](screenshots/02-pipeline-stage-view.png) |
| Console output | ![console](screenshots/03-console-output.png) |
| App running | ![app](screenshots/04-app-running.png) |
| Auto-triggered build | ![trigger](screenshots/05-auto-trigger.png) |

## Troubleshooting

- **`docker: command not found` in a build:** Jenkins is running without the Docker CLI; use `jenkins/Dockerfile`.
- **`permission denied ... docker.sock`:** run the Jenkins container as root (`-u root`) or add the `jenkins` user to the docker group.
- **Port 3000 already in use:** change `HOST_PORT` in the Jenkinsfile.
- **Jenkins on Windows (no Docker-in-Jenkins):** replace `sh` with `bat` in the Jenkinsfile and adjust the shell loop in *Verify*.

## What I learned

- Writing a declarative Jenkinsfile with stages, environment variables, triggers and `post` actions
- Automating Docker image builds and container deployment from Jenkins
- Using a multi-stage Dockerfile so tests gate the deployment
- Triggering builds from commits via webhook or SCM polling
