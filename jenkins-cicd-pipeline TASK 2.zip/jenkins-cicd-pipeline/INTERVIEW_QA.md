# Interview Questions: Jenkins CI/CD

## 1. What is Jenkins, and how is it used in CI/CD?
Jenkins is an open-source automation server written in Java. It watches a source repository, and on each change it runs a defined workflow: build the code, run tests, package it and deploy it. This is **Continuous Integration** (merge and verify often) and **Continuous Delivery/Deployment** (release automatically). Its plugin ecosystem (Git, Docker, Kubernetes, Slack, etc.) lets it plug into almost any toolchain.

## 2. What is a Jenkinsfile?
A text file, usually named `Jenkinsfile` and stored in the root of the project repo, that defines the pipeline as code (written in a Groovy-based DSL). Because it lives in version control, the pipeline is reviewed, versioned and reproducible along with the application code.

## 3. How do you create and configure Jenkins pipelines?
1. Install Jenkins and the required plugins (Git, Pipeline, Docker Pipeline)
2. Add a `Jenkinsfile` to the repo
3. In Jenkins: **New Item → Pipeline**
4. Choose **Pipeline script from SCM**, set the Git URL, branch and script path
5. Configure a trigger (GitHub webhook or Poll SCM) and any credentials
6. Save and **Build Now**, then watch the stage view and console output

(Alternatively use a **Multibranch Pipeline**, which creates a job per branch automatically.)

## 4. What are some common stages in a Jenkins pipeline?
- **Checkout**: fetch source code
- **Build**: compile or package (e.g. `docker build`)
- **Test**: unit and integration tests
- **Code quality / security scan**: lint, SonarQube, dependency or image scanning
- **Package / Publish**: push the image or artifact to a registry
- **Deploy**: release to staging or production
- **Verify / Smoke test**: confirm the deployment is healthy
- **Notify**: Slack or email results (usually in `post`)

## 5. Declarative vs scripted pipeline?

| | Declarative | Scripted |
|---|---|---|
| Syntax | Structured, starts with `pipeline { }` | Free-form Groovy, starts with `node { }` |
| Learning curve | Easier, opinionated | Steeper, more flexible |
| Structure | Fixed sections: `agent`, `stages`, `post`, `environment`, `options` | Whatever you code |
| Error handling | Built-in `post` conditions | `try/catch/finally` |
| Best for | Most projects, readability | Complex logic and dynamic flows |

```groovy
// Declarative
pipeline {
  agent any
  stages {
    stage('Build') { steps { sh 'docker build -t app .' } }
  }
}

// Scripted
node {
  stage('Build') {
    sh 'docker build -t app .'
  }
}
```
